﻿Imports System.Data.SqlClient
Imports System.Data.SqlTypes

Public Class Transfer
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Dim from As String
    Dim dest As String
    Dim amount As SqlMoney
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        from = TextBox1.Text
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        dest = TextBox2.Text
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        amount = TextBox3.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim fromFound As Boolean
        Dim toFound As Boolean
        Dim oriFrom As SqlMoney
        Dim oriTo As SqlMoney

        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT aNumber, aBalance FROM Accounts"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()

            results = (myReader.GetString(0))
            Dim original As SqlMoney = (myReader.GetSqlMoney(1))
            If results = from Then
                fromFound = True
                oriFrom = original
            End If
            If results = dest Then
                toFound = True
                oriTo = original
            End If
        Loop
        myReader.Close()

        If fromFound = True And toFound = True Then
            myCmd.CommandText = "UPDATE Accounts SET aBalance = @Fam WHERE aNumber = @fr "
            myCmd.Parameters.Add(New SqlParameter("@Fam", (oriFrom - amount)))
            myCmd.Parameters.Add(New SqlParameter("@fr", from))
            myCmd.ExecuteNonQuery()

            myCmd.CommandText = "UPDATE Accounts SET aBalance = @Tam WHERE aNumber = @de "
            myCmd.Parameters.Add(New SqlParameter("@Tam", (oriTo + amount)))
            myCmd.Parameters.Add(New SqlParameter("@de", dest))
            myCmd.ExecuteNonQuery()

            myCmd.CommandText = "INSERT INTO Transactions(tAccountNumber, tType, tAmount, tDescription) VALUES(@fr, @t, @amo, @n)"
            myCmd.Parameters.Add(New SqlParameter("@t", "transfer-"))
            myCmd.Parameters.Add(New SqlParameter("@amo", amount))
            myCmd.Parameters.Add(New SqlParameter("@n", "Pending"))
            myCmd.ExecuteNonQuery()

            myCmd.CommandText = "INSERT INTO Transactions(tAccountNumber, tType, tAmount, tDescription) VALUES(@de, @tt, @amo, @n)"
            myCmd.Parameters.Add(New SqlParameter("@tt", "transfer+"))
            myCmd.ExecuteNonQuery()

            MessageBox.Show("Transfer Successful")
        Else
            MessageBox.Show("Account Number(s) not Found")
        End If


        myConn.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class