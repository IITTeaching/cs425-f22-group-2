﻿Imports System.Data.SqlClient

Public Class CustomerInfo
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Dim uName As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT aOwner, aNumber, aBalance, aType FROM Accounts"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            Dim uO As String = myReader.GetString(0)
            Dim aN As String = myReader.GetString(1)
            Dim aB As String = myReader.GetSqlMoney(2)
            Dim aT As String = myReader.GetString(3)
            If uO = (uName) Then
                MessageBox.Show("Name: " & uO & vbCrLf & "Account Number: " & aN & vbCrLf & "Account Balance: $" & aB & vbCrLf & "Account Type: " & aT)

            End If

        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        uName = TextBox1.Text
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class