﻿Imports System.Xml.Serialization
Imports System.Data.SqlClient
Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim loginType As Char
    Dim validType As Boolean
    Dim correctUser As Boolean 'if all login parts true, this is true'
    'compare login'
    Public userInput As String
    Dim passInput As String

    Dim test As String

    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String


    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        'customer portal'
        loginType = "c"
        validType = True
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        'Teller portal'
        loginType = "t"
        validType = True
    End Sub

    Public Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        'username'
        userInput = TextBox1.Text

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        'passeord'
        passInput = TextBox2.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'sql connection to user table'
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT uName, uPassword, uType FROM Users"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()

            'results = results & myReader.GetString(0) & vbTab & myReader.GetString(1) & vbLf
            results = (myReader.GetString(0) & myReader.GetString(1) & myReader.GetString(2))
            test = (userInput & passInput & loginType)
            'MessageBox.Show(userInput)
            'MessageBox.Show(passInput)


            If results = (userInput & passInput & loginType) Then
                correctUser = True
                If loginType = "c" Then
                    Me.Hide()
                    Customer.Show()
                End If
                If loginType = "t" Then
                    Me.Hide()
                    Teller.Show()
                End If
                If loginType = "l" Then
                    Me.Hide()
                    LoanSpecialist.Show()
                End If
                If loginType = "m" Then
                    Me.Hide()
                    Manager.Show()
                End If

            End If
            'MessageBox.Show(test)
            'MessageBox.Show(results)
        Loop

        myReader.Close()
        myConn.Close()

        If validType = False Then
            MessageBox.Show("Please Select Customer or Employee.")
        End If
        If correctUser = False Then
            MessageBox.Show("Incorrect Credentials. Try Again.")
        End If

    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        'LoanSpecialist portal'
        loginType = "l"
        validType = True
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        'Manager portal'
        loginType = "m"
        validType = True
    End Sub
End Class
