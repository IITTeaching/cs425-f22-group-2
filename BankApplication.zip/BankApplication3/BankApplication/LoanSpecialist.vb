﻿Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Net
Imports System.Security.AccessControl
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView

Public Class LoanSpecialist
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Dim aNum As String
    Dim amo As SqlMoney
    Dim runtime As Integer
    Dim interest As SqlDecimal

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT cName FROM Customers"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            results = myReader.GetString(0)
            If results = (Form1.userInput) Then
                Label1.Text = results

            End If

        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT cName, cHomeBranch FROM Customers"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            Dim uName As String = myReader.GetString(0)
            results = myReader.GetString(1)
            If uName = (Form1.userInput) Then
                Label2.Text = ("Home Branch: " & results)

            End If

        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        aNum = TextBox3.Text
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        amo = TextBox4.Text
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        runtime = TextBox5.Text
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        interest = TextBox6.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CustomerInfo.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")

        myConn.Open()
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "INSERT INTO Loans(lHolder, lAmount, lRuntime, lInterestSchedule) VALUES (@s, @d, @f, @g)"
        myCmd.Parameters.Add(New SqlParameter("@s", aNum))
        myCmd.Parameters.Add(New SqlParameter("@d", amo))
        myCmd.Parameters.Add(New SqlParameter("@f", runtime))
        myCmd.Parameters.Add(New SqlParameter("@g", interest))
        myReader = myCmd.ExecuteReader()

        MessageBox.Show("Loan Creation Successful")


        myConn.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class