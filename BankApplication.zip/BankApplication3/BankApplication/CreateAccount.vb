﻿Imports System.Data.SqlClient
Imports System.Data.SqlTypes

Public Class CreateAccount
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Dim accType As String
    Dim fName As String
    Dim lName As String
    Dim accNum As String
    Dim bal As SqlMoney
    Dim address As String
    Dim branch As String

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        'read account type'
        accType = ComboBox1.Text
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        'first name'
        fName = TextBox1.Text
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        'last name'
        lName = TextBox2.Text
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        'acc num'
        accNum = TextBox3.Text
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        'balance'
        bal = TextBox4.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'submit, messagebox complete, error check messagebox later'
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        Dim fullName As String = (fName & " " & lName)
        Dim oldCus As Boolean

        myConn.Open()

        myCmd = myConn.CreateCommand

        myCmd.CommandText = "SELECT cName FROM Customers"
        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            results = myReader.GetString(0)
            If results = (fullName) Then
                myCmd.CommandText = "INSERT INTO Accounts(aOwner, aNumber, aBalance, aType) VALUES(@a, @b, @c, @d)"
                oldCus = True
            End If
        Loop
        myReader.Close()

        If oldCus = False Then
            myCmd.CommandText = "INSERT INTO Customers(cName, cAddress, cHomeBranch) VALUES(@a, @y, @z)"
            myCmd.Parameters.Add(New SqlParameter("@a", fullName))
            myCmd.Parameters.Add(New SqlParameter("@y", address))
            myCmd.Parameters.Add(New SqlParameter("@z", branch)) ' will crash if inserts branch that doesn't exist'
            myCmd.ExecuteNonQuery()

            myCmd.CommandText = "INSERT INTO Accounts(aOwner, aNumber, aBalance, aType) VALUES(@a, @b, @c, @d)"
            myCmd.Parameters.Add(New SqlParameter("@b", accNum))
            myCmd.Parameters.Add(New SqlParameter("@c", bal))
            myCmd.Parameters.Add(New SqlParameter("@d", accType))
            myCmd.ExecuteNonQuery()
        End If


        myCmd.CommandText = "SELECT aNumber FROM Accounts"
        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            results = myReader.GetString(0)
            If results = (accNum) Then
                MessageBox.Show("Insert Successful")
            End If
        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        address = TextBox5.Text
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        branch = TextBox6.Text
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class