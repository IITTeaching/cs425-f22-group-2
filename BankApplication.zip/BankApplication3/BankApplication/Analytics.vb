﻿Imports System.Data.SqlClient
Imports System.Data.SqlTypes

Public Class Analytics
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'output bank's total money'
        Dim total As SqlMoney = 0
        Dim bal As SqlMoney

        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT aBalance FROM Accounts"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            bal = myReader.GetSqlMoney(0)
            total = total + bal
        Loop

        myReader.Close()
        myConn.Close()

        MessageBox.Show(total)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'output total amount of loans the bank has given'
        Dim total As SqlMoney = 0
        Dim bal As SqlMoney

        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT lAmount FROM Loans"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            bal = myReader.GetSqlMoney(0)
            total = total + bal
        Loop

        myReader.Close()
        myConn.Close()

        MessageBox.Show(total)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'list of loan people and how much they took out'

        Dim list As String = ""

        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT lHolder, lAmount FROM Loans"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            Dim name As String = myReader.GetString(0)
            Dim amo As String = myReader.GetSqlMoney(1)
            list = ("Loan Holder: " & name & "; Loan Amount: " & amo & vbCrLf)
        Loop

        myReader.Close()
        myConn.Close()

        MessageBox.Show(list)

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class