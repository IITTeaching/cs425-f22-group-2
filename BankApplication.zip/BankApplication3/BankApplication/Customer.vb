﻿Imports System.Xml.Serialization
Imports System.Data.SqlClient
Imports Microsoft.VisualBasic.ApplicationServices
Imports System.Data.SqlTypes

Public Class Customer
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    'variables'
    Dim cusName As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CreateAccount.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Delete.Show()
    End Sub

    Public Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        'display customer name'
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT cName FROM Customers"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            results = myReader.GetString(0)
            If results = (Form1.userInput) Then
                Label1.Text = results

            End If

        Loop

        myReader.Close()
        myConn.Close()
        'Label1.Text = Form1.userInput

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click


        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT cName, cHomeBranch FROM Customers"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            Dim uName As String = myReader.GetString(0)
            results = myReader.GetString(1)
            If uName = (Form1.userInput) Then
                Label2.Text = ("Home Branch: " & results)

            End If

        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'view customer information'
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT aOwner, aNumber, aBalance, aType FROM Accounts"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            Dim uName As String = myReader.GetString(0)
            Dim aN As String = myReader.GetString(1)
            Dim aB As String = myReader.GetSqlMoney(2)
            Dim aT As String = myReader.GetString(3)
            If uName = (Form1.userInput) Then
                MessageBox.Show("Name: " & uName & vbCrLf & "Account Number: " & aN & vbCrLf & "Account Balance: $" & aB & vbCrLf & "Account Type: " & aT)

            End If

        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class