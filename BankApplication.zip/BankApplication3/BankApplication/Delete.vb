﻿Imports System.Buffers
Imports System.Data.SqlClient

Public Class Delete
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Dim accNum As String
    Dim found As Boolean

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        'read account number'
        accNum = TextBox1.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'submit button deletes items if account number matches, messagebox complete. if no match, messagebox error'

        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT aNumber FROM Accounts"

        myConn.Open()
        myCmd.ExecuteNonQuery()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            results = (myReader.GetString(0))
            If results = accNum Then
                found = True
            End If

        Loop

        myReader.Close()


        If found = True Then
            myCmd.CommandText = "DELETE FROM Accounts WHERE aNumber = @accNum"
            myCmd.Parameters.Add(New SqlParameter("@accNum", accNum))
            myCmd.ExecuteNonQuery()

            MessageBox.Show("delete successful")

        End If

        myConn.Close()
        If found = False Then
            MessageBox.Show("account number not found")
        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class