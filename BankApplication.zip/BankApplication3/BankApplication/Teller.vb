﻿Imports System.Data.SqlClient

Public Class Teller
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Transfer.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ExternalTransfer.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Deposit.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Withdrawl.Show()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT eName FROM Employees"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            results = myReader.GetString(0)
            If results = (Form1.userInput) Then
                Label1.Text = results

            End If

        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT eName, eWBName FROM Employees"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()
            Dim uName As String = myReader.GetString(0)
            results = myReader.GetString(1)
            If uName = (Form1.userInput) Then
                Label2.Text = ("Home Branch: " & results)

            End If

        Loop

        myReader.Close()
        myConn.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CustomerInfo.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class