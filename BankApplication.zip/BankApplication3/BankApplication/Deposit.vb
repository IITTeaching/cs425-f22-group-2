﻿Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Security.AccessControl
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Deposit
    Inherits System.Windows.Forms.Form
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Dim accNum As String
    Dim amount As SqlMoney
    Dim original As SqlMoney



    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        'account number'
        accNum = TextBox2.Text
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        'deposit amount'
        amount = TextBox1.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'submit & message box complete'
        Dim found As Boolean
        Dim ori As SqlMoney

        myConn = New SqlConnection("Initial Catalog=425 Banking App;" & "Data Source=localhost;Integrated Security=SSPI;")
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "SELECT aNumber, aBalance FROM Accounts"
        myConn.Open()

        myReader = myCmd.ExecuteReader()
        Do While myReader.Read()

            results = (myReader.GetString(0))
            original = (myReader.GetSqlMoney(1))
            If results = accNum Then
                found = True
                ori = original
            End If
        Loop
        myReader.Close()

        If found = True Then
            myCmd.CommandText = "UPDATE Accounts SET aBalance = @am WHERE aNumber = @num "
            myCmd.Parameters.Add(New SqlParameter("@am", (ori + amount)))
            myCmd.Parameters.Add(New SqlParameter("@num", accNum))
            myCmd.ExecuteNonQuery()

            myCmd.CommandText = "INSERT INTO Transactions(tAccountNumber, tType, tAmount, tDescription) VALUES(@an, @t, @amo, @n)"
            myCmd.Parameters.Add(New SqlParameter("@an", accNum))
            myCmd.Parameters.Add(New SqlParameter("@t", "deposit"))
            myCmd.Parameters.Add(New SqlParameter("@amo", amount))
            myCmd.Parameters.Add(New SqlParameter("@n", "Pending"))
            myCmd.ExecuteNonQuery()
            MessageBox.Show("Deposit Successful")
        Else
            MessageBox.Show("Account Number not Found")
        End If


        myConn.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
End Class